% PLOT FIGURE FOR WAVELET TREE SPEEF
% small scale
maxNumCompThreads(1); % makes sure it runs on one thread
clear all;

% fix random seed for reproducibility
seed=1
rand('state',seed);
randn('state',seed);


d = 7;
n = 200;
x = rand(n,1);
noise = 0.1;
g = (0:.0005:1)';
xx = [ x; g];

% build haar wavelets on data and grid
k=1;
for i=1:d
    for j=1:2:2^i-1
        psilox = x * 0;
        wavelets(:,k) =  ( ( (xx>(j-1)/2^i) & (xx<=j/2^i) )  -  ( (xx>j/2^i) & (xx<=(j+1)/2^i) ) ) * 2^(i/2);
        supports(k,:) = [(j-1)/2^i, (j+1)/2^i];
        depth(k)=i;
        k=k+1;
    end
end
X = wavelets(1:n,:);
Xg = wavelets(n+1:end,:);
% rescale to unit norm
normalization = mean(Xg.^2);
Xg = Xg ./ repmat(normalization,size(Xg,1),1);
X = X ./ repmat(normalization,size(X,1),1);


means = mean(X,1);
X = X - repmat(means,n,1);
Xg = Xg - repmat(means,size(Xg,1),1);
y = sin(10*pi*x.^2) + noise * randn(n,1);
meany = mean(y);
yc = y - meany;

% build tree structure and order
p = 2^d-1;
tree = sparse(logical(zeros(p,p)));
children = sparse(logical(zeros(p,p)));
for i=1:p
    for j=1:p
        if (supports(i,1)>=supports(j,1)) & (supports(i,2)<=supports(j,2))
            tree(j,i) = 1;
            if ( supports(i,2) - supports(i,1) ) == ( supports(j,2) - supports(j,1) ) / 2
                children(j,i) = 1;
            end
            
        end
    end
end
order = p:-1:1;
weights = (depth').^0;
param_F.p = p;
param_F.tree = tree;
param_F.weights = weights;
F = @submodular_fct_trees;


% remove tiny singular values from X
[n p] = size(X);
[UX,sX,VX] = svd(X,'econ');
ind = find(diag(sX)>1e-10);
X = UX(:,ind)*sX(ind,ind)*VX(:,ind)';


lambda = 1e-2;
L = max(eig(X'*X)/n);


% FISTA PROX HIERARCHIC
tic
w = zeros(p,1);
v = w;
t = 1;
maxiter = 2000;
values_fista_hierarchic = zeros(maxiter,1);
times_fista_hierarchic = zeros(maxiter,1);

for iter=1:maxiter
    if mod(iter,100)==1, iter, end
    gradient = 1/n*X'*(X*v-yc);
    wold = w;
    w = v-1/L * gradient;
    for i=order
        group = find(tree(i,:));
        w(group) = prox_operator_Linf(w(group), weights(i) * lambda/L);
    end
    told = t;
    t = (1 + sqrt( 1+ 4*t*t ) )/2;
    vold = v;
    v = w + ( told - 1 ) / t * ( w - wold);
    % values_fista_hierarchic(iter) = 1/n/2*norm(X*w-yc)^2 + lambda * lovasz_extension(abs(w),F,param_F);
    values_fista_hierarchic(iter) = 1/n/2*norm(X*w-yc)^2 + lambda * param_F.weights'*max(param_F.tree * diag(abs(w)),[],2);
    
    times_fista_hierarchic(iter) = toc;
end
toc





% FISTA PROX DECOMPOSITION
tic
w = zeros(p,1);
v = w;
t = 1;
maxiter = 500;
values_fista_decomposition = zeros(maxiter,1);
times_fista_decomposition = zeros(maxiter,1);

for iter=1:maxiter
    if mod(iter,100)==1, iter, end
    
    gradient = 1/n*X'*(X*v-yc);
    wold = w;
    w = prox_operator_submodular_absolute_tree(v-1/L * gradient,lambda/L,tree,weights,order,children);
    
    told = t;
    t = (1 + sqrt( 1+ 4*t*t ) )/2;
    vold = v;
    v = w + ( told - 1 ) / t * ( w - wold);
    % values_fista_decomposition(iter) = 1/n/2*norm(X*w-yc)^2 + lambda * lovasz_extension(abs(w),F,param_F);
    values_fista_decomposition(iter) = 1/n/2*norm(X*w-yc)^2 + lambda * param_F.weights'*max(param_F.tree * diag(abs(w)),[],2);
    times_fista_decomposition(iter) = toc;
end
toc



% FISTA PROX DECOMPOSITION - ABS
tic
w = zeros(p,1);
v = w;
t = 1;
maxiter = 500;
values_fista_decomposition_abs = zeros(maxiter,1);
times_fista_decomposition_abs = zeros(maxiter,1);

for iter=1:maxiter
    if mod(iter,100)==1, iter, end
    
    gradient = 1/n*X'*(X*v-yc);
    wold = w;
    w = prox_operator_submodular_absolute_tree_alt(v-1/L * gradient,lambda/L,tree,weights,order,children);
    
    told = t;
    t = (1 + sqrt( 1+ 4*t*t ) )/2;
    vold = v;
    v = w + ( told - 1 ) / t * ( w - wold);
    % values_fista_decomposition(iter) = 1/n/2*norm(X*w-yc)^2 + lambda * lovasz_extension(abs(w),F,param_F);
    values_fista_decomposition_abs(iter) = 1/n/2*norm(X*w-yc)^2 + lambda * param_F.weights'*max(param_F.tree * diag(abs(w)),[],2);
    times_fista_decomposition_abs(iter) = toc;
end
toc






% FISTA PROX FW MIN-NORM POINT - with bundle
% save time
tic
w = zeros(p,1);
v = w;
t = 1;
maxiter = 500;
values_fista = zeros(maxiter,1);
times_fista = zeros(maxiter,1);

for iter=1:maxiter
    gradient = 1/n*X'*(X*v-yc);
    wold = w;
    if mod(iter,100)==1, iter, end
    
    if iter ==1
        [w,bundle] = prox_operator_submodular_absolute(v-1/L * gradient,lambda/L,F,param_F,1e-2/iter.^3);
        
    else
        [w,bundle] = prox_operator_submodular_absolute(v-1/L * gradient,lambda/L,F,param_F,1e-2/iter.^3,bundle);
    end
    
    told = t;
    t = (1 + sqrt( 1+ 4*t*t ) )/2;
    vold = v;
    v = w + ( told - 1 ) / t * ( w - wold);
    % values_fista(iter) = 1/n/2*norm(X*w-yc)^2 + lambda * lovasz_extension(abs(w),F,param_F);
    values_fista(iter) = 1/n/2*norm(X*w-yc)^2 + lambda * param_F.weights'*max(param_F.tree * diag(abs(w)),[],2);
    times_fista(iter) = toc;
end
toc



% FISTA PROX FW MIN-NORM POINT - with bundle
% save time
tic
w = zeros(p,1);
v = w;
t = 1;
maxiter = 500;
values_fista_abs = zeros(maxiter,1);
times_fista_abs = zeros(maxiter,1);

for iter=1:maxiter
    gradient = 1/n*X'*(X*v-yc);
    wold = w;
    if mod(iter,100)==1, iter, end
    
    if  iter ==1
        [w,bundle] = prox_operator_submodular_absolute_alt(v-1/L * gradient,lambda/L,F,param_F,1e-2/iter.^3);
    else
        [w,bundle] = prox_operator_submodular_absolute_alt(v-1/L * gradient,lambda/L,F,param_F,1e-2/iter.^3,bundle);
    end
    
    told = t;
    t = (1 + sqrt( 1+ 4*t*t ) )/2;
    vold = v;
    v = w + ( told - 1 ) / t * ( w - wold);
    % values_fista(iter) = 1/n/2*norm(X*w-yc)^2 + lambda * lovasz_extension(abs(w),F,param_F);
    values_fista_abs(iter) = 1/n/2*norm(X*w-yc)^2 + lambda * param_F.weights'*max(param_F.tree * diag(abs(w)),[],2);
    times_fista_abs(iter) = toc;
end
toc








% FISTA PROX FW MIN-NORM POINT - without bundle
% save time
tic
w = zeros(p,1);
v = w;
t = 1;
maxiter = 500;
values_fista_nobundle = zeros(maxiter,1);
times_fista_nobundle = zeros(maxiter,1);

for iter=1:maxiter
    gradient = 1/n*X'*(X*v-yc);
    wold = w;
    if mod(iter,100)==1, iter, end
    
    
    w = prox_operator_submodular_absolute(v-1/L * gradient,lambda/L,F,param_F,1e-2/iter.^3);
    
    
    told = t;
    t = (1 + sqrt( 1+ 4*t*t ) )/2;
    vold = v;
    v = w + ( told - 1 ) / t * ( w - wold);
    % values_fista(iter) = 1/n/2*norm(X*w-yc)^2 + lambda * lovasz_extension(abs(w),F,param_F);
    values_fista_nobundle(iter) = 1/n/2*norm(X*w-yc)^2 + lambda * param_F.weights'*max(param_F.tree * diag(abs(w)),[],2);
    times_fista_nobundle(iter) = toc;
end
toc



% FISTA PROX FW MIN-NORM POINT - without bundle
% save time
tic
w = zeros(p,1);
v = w;
t = 1;
maxiter = 500;
values_fista_abs_nobundle = zeros(maxiter,1);
times_fista_abs_nobundle = zeros(maxiter,1);

for iter=1:maxiter
    gradient = 1/n*X'*(X*v-yc);
    wold = w;
    if mod(iter,100)==1, iter, end
    
    
    w = prox_operator_submodular_absolute_alt(v-1/L * gradient,lambda/L,F,param_F,1e-2/iter.^3);
    
    told = t;
    t = (1 + sqrt( 1+ 4*t*t ) )/2;
    vold = v;
    v = w + ( told - 1 ) / t * ( w - wold);
    % values_fista(iter) = 1/n/2*norm(X*w-yc)^2 + lambda * lovasz_extension(abs(w),F,param_F);
    values_fista_abs_nobundle(iter) = 1/n/2*norm(X*w-yc)^2 + lambda * param_F.weights'*max(param_F.tree * diag(abs(w)),[],2);
    times_fista_abs_nobundle(iter) = toc;
end
toc








% SUBGRADIENT DESCENT - try several values of the step size
tic

maxiter = 2000;
constant_values = 2.^[-6:2:4];
values_sgd = zeros(maxiter,length(constant_values));
times_sgd = zeros(maxiter,length(constant_values));

for iconstant=1:length(constant_values)
    w = zeros(p,1);
    tic
    for iter=1:maxiter
        if mod(iter,100)==1, iter, end
        gradient = 1/n*X'*(X*w-yc);
        s = greedy_algo_submodular(abs(w),F,param_F);
        w = w - ( gradient + lambda * s .* sign(w) ) / sqrt(2 * iter) / L * constant_values(iconstant);
        values_sgd(iter,iconstant) = 1/n/2*norm(X*w-yc)^2 + lambda * param_F.weights'*max(param_F.tree * diag(abs(w)),[],2);
        times_sgd(iter,iconstant) = toc;
    end
end
toc
[a,b]=min(values_sgd(end,:));
times_sgd = times_sgd(:,b);
values_sgd = values_sgd(:,b);



% ACTIVE SET - primal
maxiter = 1000;
[beta,values_active_primal,duals,gaps,times_active_primal] = least_squares_tree(yc,X,tree,weights*lambda,order,children,maxiter);



% ACTIVE SET - dual
maxiter = 1000;
param_F.p = p;
param_F.tree = tree;
param_F.weights = weights;
F = @submodular_fct_trees;
[beta,values_active_dual,duals,gaps,times_active_dual] = least_squares_dual_active_set(yc,X,F,param_F,lambda,maxiter,1e-12);


minvalue = min([ min(values_fista_hierarchic), min(values_active_dual), min(values_active_primal)]) -1e-16;

plot(times_sgd-times_sgd(1),cummin(log10(values_sgd-minvalue  )),'g','linewidth',2); hold on
plot(times_fista-times_fista(1),cummin(log10(values_fista-minvalue )),'k','linewidth',2); hold on;
plot(times_fista_nobundle-times_fista_nobundle(1),cummin(log10(values_fista_nobundle-minvalue )),'k--','linewidth',2); hold on;
plot(times_fista_abs-times_fista_abs(1),cummin(log10(values_fista_abs-minvalue )),'k:','linewidth',2); hold on;
plot(times_fista_decomposition-times_fista_decomposition(1),cummin(log10(values_fista_decomposition-minvalue )),'b','linewidth',2); hold on;
plot(times_fista_decomposition_abs-times_fista_decomposition_abs(1),cummin(log10(values_fista_decomposition_abs-minvalue )),'b:','linewidth',2); hold on;
plot(times_fista_hierarchic(1:1500)-times_fista_hierarchic(1),cummin(log10(values_fista_hierarchic(1:1500)-minvalue )),'r','linewidth',2); hold on;
plot(times_active_primal-times_active_primal(1),cummin(log10(values_active_primal -minvalue )),'c','linewidth',2); hold on;
plot(times_active_dual-times_active_dual(1),cummin(log10(values_active_dual -minvalue  )),'m','linewidth',2); hold on;
plot(times_fista_abs-times_fista_abs(1),cummin(log10(values_fista_abs-minvalue )),'k:','linewidth',2); hold on;
set(gca,'fontsize',18)
legend('Subgrad. descent','Prox. MNP','Prox. MNP (no restart)','Prox. MNP (abs)','Prox. decomp.','Prox. decomp. (abs)','Prox. hierarchical','Active-primal','Active-dual','Location','NorthEastOutside');
xlabel('time (seconds)');
ylabel('log_{10}(g(w) - min(g))');
axis([ 0 9 -11 -1 ])
hold off

