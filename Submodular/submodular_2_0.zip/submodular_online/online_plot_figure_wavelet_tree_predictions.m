% PLOT FIGURE FOR WAVELET TREES
% prediction results

maxNumCompThreads(1); % makes sure it runs on one thread
clear all;

% fix random seed for reproducibility
seed=1;
rand('state',seed);
randn('state',seed);


d = 9;
n = 150;
x = rand(n,1);
x = (0:(n-1))' / (n-1);
xtest = rand(n,1);
xtest = (0:(n-1))' / (n-1);
noise = 0.2;
g = (0:.0005:1)';
xx = [ x; xtest; g];

% build haar wavelets on data and grid
k=1;
for i=1:d
    for j=1:2:2^i-1
        psilox = x * 0;
        wavelets(:,k) =  ( ( (xx>(j-1)/2^i) & (xx<=j/2^i) )  -  ( (xx>j/2^i) & (xx<=(j+1)/2^i) ) ) * 2^(i/2);
        supports(k,:) = [(j-1)/2^i, (j+1)/2^i];
        depth(k)=i;
        %    plot(wavelets(:,k),'x-');
        %    pause
        k=k+1;
    end
end
X = wavelets(1:n,:);
Xtest = wavelets(n+1:2*n,:);
Xg = wavelets(2*n+1:end,:);

% rescale to unit norm
normalization = mean(Xg.^2);
Xg = Xg ./ repmat(normalization,size(Xg,1),1);
X = X ./ repmat(normalization,size(X,1),1);
Xtest = Xtest ./ repmat(normalization,size(Xtest,1),1);


means = mean(X,1);
X = X - repmat(means,n,1);
Xtest = Xtest - repmat(means,n,1);
Xg = Xg - repmat(means,size(Xg,1),1);
y = sin(8*pi*x.^2) + noise * randn(n,1);
ytest = sin(8*pi*xtest.^2) + noise * randn(n,1);
meany = mean(y);
yc = y - meany;

% build tree structure and order
p = 2^d-1;
tree = sparse(logical(zeros(p,p)));
children = sparse(logical(zeros(p,p)));
for i=1:p
    for j=1:p
        if (supports(i,1)>=supports(j,1)) & (supports(i,2)<=supports(j,2))
            tree(j,i) = 1;
            if ( supports(i,2) - supports(i,1) ) == ( supports(j,2) - supports(j,1) ) / 2
                children(j,i) = 1;
            end

        end
    end
end
order = p:-1:1;
 L = max(eig(X'*X/n));


% draw tree 
figure;
subplot('position',[.4 .7 .2 .25])
plot(g,Xg(:,1),'linewidth',2); grid on % axis off
set(gca,'fontsize',12)
subplot('position',[.15 .4 .2 .25])
plot(g,Xg(:,2),'linewidth',2); grid on % axis off
set(gca,'fontsize',12)
subplot('position',[.65 .4 .2 .25])
plot(g,Xg(:,3),'linewidth',2); grid on  %axis off
set(gca,'fontsize',12)
subplot('position',[.025 .1 .2 .25])
plot(g,Xg(:,4),'linewidth',2);  grid on %axis off
set(gca,'fontsize',12)
subplot('position',[.275 .1 .2 .25])
plot(g,Xg(:,5),'linewidth',2);  grid on %axis off
set(gca,'fontsize',12)
subplot('position',[.525 .1 .2 .25])
plot(g,Xg(:,6),'linewidth',2);  grid on %axis off
set(gca,'fontsize',12)
subplot('position',[.775 .1 .2 .25])
plot(g,Xg(:,7),'linewidth',2);  grid on %axis off
set(gca,'fontsize',12)



% find best ridge regression
lambdas = 10.^[1:-.25:-4.5];
for ilambda = 1:length(lambdas)
    w = (X'*X + n*lambdas(ilambda) * eye(p) ) \ (X'*yc);
    errors_ridge(ilambda) =norm( sin(8*pi*x.^2) - X*w - meany);
    test_errors_ridge(ilambda) =norm( ytest - Xtest*w - meany);
        true_errors_ridge(ilambda) =norm( sin(8*pi*g.^2) - Xg*w - meany);

end
[a,b] = min(test_errors_ridge);
w_ridge = (X'*X + n*lambdas(b) * eye(p)) \ (X'*yc);
best_ridge = true_errors_ridge(b)






% find best hierarchic
tic
lambdas = 10.^[1:-.25:-4.5];
w = zeros(p,1);
for ilambda = 1:length(lambdas)
    lambda = lambdas(ilambda)
    v = w;
    t = 1;
    maxiter = 100;

    for iter=1:maxiter
        gradient = 1/n*X'*(X*v-yc);
        wold = w;
        w = v-1/L * gradient;
        for i=order
            group = find(tree(i,:));
             w(group) = prox_operator_Linf(w(group), lambda/L);
            %  w(group) = ( w(group) / (1e-12+norm(w(group)))) * max( norm(w(group)) -  lambda/L, 0 );

        end
        told = t;
        t = (1 + sqrt( 1+ 4*t*t ) )/2;
        vold = v;
        v = w + ( told - 1 ) / t * ( w - wold);
    end
    errors_hier(ilambda) =norm( sin(8*pi*x.^2) - X*w - meany);
    test_errors_hier(ilambda) =norm( ytest - Xtest*w - meany);
    true_errors_hier(ilambda) =norm( sin(8*pi*g.^2) - Xg*w - meany);

    ws(:,ilambda) = w;
end

[a,b] = min(test_errors_hier);
w_hier = ws(:,b);
best_hier = true_errors_hier(b)




% find best lasso
tic
lambdas = 10.^[1:-.25:-4.5];
w = zeros(p,1);
for ilambda = 1:length(lambdas)
    lambda = lambdas(ilambda)
    v = w;
    t = 1;
    maxiter = 150;

    for iter=1:maxiter
        gradient = 1/n*X'*(X*v-yc);
        wold = w;
        w = v-1/L * gradient;
        w = sign(w) .* ( max(abs(w) - lambda , 0 ) );
        told = t;
        t = (1 + sqrt( 1+ 4*t*t ) )/2;
        vold = v;
        v = w + ( told - 1 ) / t * ( w - wold);
    end
    errors_lasso(ilambda) =norm( sin(8*pi*x.^2) - X*w - meany);
    test_errors_lasso(ilambda) =norm( ytest - Xtest*w - meany);
    true_errors_lasso(ilambda) =norm( sin(8*pi*g.^2) - Xg*w - meany);

    ws(:,ilambda) = w;
end

[a,b] = min(test_errors_lasso);
w_lasso = ws(:,b);
best_lasso = true_errors_lasso(b)

figure
subplot(1,3,1);
plot(g,Xg*w_hier + meany,'b', 'linewidth',2 ); hold on;
plot(g, sin(8*pi*g.^2),'r' ); hold off;
axis([0 1 -1.2 1.2 ]);
set(gca,'fontsize',18)
hold off
title('Hierarchic');

subplot(1,3,2);
plot(g,Xg*w_lasso + meany,'b', 'linewidth',2 ); hold on;
plot(g, sin(8*pi*g.^2),'r' ); hold off;
axis([0 1 -1.2 1.2 ]);
set(gca,'fontsize',18)
hold off
title('Lasso');


subplot(1,3,3);
plot(g,Xg*w_ridge + meany,'b', 'linewidth',2 ); hold on;
plot(g, sin(8*pi*g.^2),'r' ); hold off;
axis([0 1 -1.2 1.2 ]);
set(gca,'fontsize',18)
hold off
title('Ridge');
[best_hier,best_lasso,best_ridge].^2 / length(g)





