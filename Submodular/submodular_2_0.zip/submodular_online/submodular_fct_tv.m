function F = submodular_fct_tv(A,param_F);
% 1D total variation
x = sparse(zeros(param_F.p,1)); x(A)=1;
F = sum( abs( x(1:param_F.p-1)-  x(2:param_F.p)) );
 
