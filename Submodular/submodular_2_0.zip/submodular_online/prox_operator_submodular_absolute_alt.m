function [w,bundle] = prox_operator_submodular_absolute_alt(z,lambda,F,param_F,gap,bundle);
% minimize lambda * f(|w|) + .5 * || w - z ||^2
% using the MNP algorithm directly on the symmetric polyhedron
if nargin<5, gap = 1e-8; end

if nargin == 6
    [s,t1,t2,t3,bundle] = minimize_submodular_FW_minnormpoint_proxabs(F,param_F,z/lambda,200,gap/lambda/lambda,bundle);
else
     [s,t1,t2,t3,bundle] = minimize_submodular_FW_minnormpoint_proxabs(F,param_F,z/lambda,200,gap/lambda/lambda);
end
w = z - lambda*s;

  