for dataset = [ 1 2 3 4 6]
    switch dataset
        case 1
            maxiter = 1000;
            amin=-1;
            amax=4.5;
            name='genrmflong';
            
            for i=1:9
                maxiter = 1500;
                gap = 1e-8;
                [primal,dual,solution,certificate] = launch_sfm(dataset,i,maxiter,1,gap);
                results{i}.primal = primal;
                results{i}.dual = dual;
                results{i}.solution = solution;
                results{i}.certificate  = certificate;
            end
            
        case 2
            amin=-1;
            amax=4.5;
            maxiter = 1500;
            name='genrmfwide';
            
            for i=1:9
                maxiter = 1500;
                gap = 1e-8;
                [primal,dual,solution,certificate] = launch_sfm(dataset,i,maxiter,1,gap);
                results{i}.primal = primal;
                results{i}.dual = dual;
                results{i}.solution = solution;
                results{i}.certificate  = certificate;
            end
            
        case 3
            amin=-4;
            amax=2;
            maxiter = 650;
            name='twomoons';
            
            for i=1:9
                maxiter = 1500;
                gap = 1e-8;
                [primal,dual,solution,certificate] = launch_sfm(dataset,i,maxiter,1,gap);
                results{i}.primal = primal;
                results{i}.dual = dual;
                results{i}.solution = solution;
                results{i}.certificate  = certificate;
            end
            
            
        case 4
            amin=-4;
            amax=2.5;
            maxiter = 400;
            name='bilmes';
            
            for i=1:9
                maxiter = 1500;
                gap = 1e-8;
                [primal,dual,solution,certificate] = launch_sfm(dataset,i,maxiter,1,gap);
                results{i}.primal = primal;
                results{i}.dual = dual;
                results{i}.solution = solution;
                results{i}.certificate  = certificate;
            end
            
            
        case 6
            
            amin=-4;
            amax=2.5;
            maxiter = 400;
            name='image';
            
            
            for i=1:9
                maxiter = 1500;
                gap = 1e-8;
                [primal,dual,solution,certificate] = launch_sfm(dataset,i,maxiter,1,gap);
                results{i}.primal = primal;
                results{i}.dual = dual;
                results{i}.solution = solution;
                results{i}.certificate  = certificate;
            end
            
            
    end
    optimal_dual = -Inf;
    optimal_primal = Inf;
    min_dual = Inf;
    max_primal = -Inf;
    max_gap = 0;
    for j=1:9
        optimal_dual = max(optimal_dual, max(results{j}.dual));
        optimal_primal = min(optimal_primal, min(results{j}.primal));
        min_dual = min( min_dual, min(results{j}.dual));
        max_primal = max( max_primal, max(results{j}.primal));
        max_gap = max( max_gap, max(results{j}.primal-results{j}.dual));
    end
    
    % primal values
    plot(cummin(log10(1e-12+results{1}.primal-optimal_dual)),'k','linewidth',2); hold on;
    plot(cummin(log10(1e-12+results{2}.primal-optimal_dual)),'r','linewidth',2); hold on;
    plot(cummin(log10(1e-12+results{3}.primal-optimal_dual)),'r--','linewidth',2); hold on;
    plot(cummin(log10(1e-12+results{4}.primal-optimal_dual)),'b','linewidth',2); hold on;
    plot(cummin(log10(1e-12+results{5}.primal-optimal_dual)),'b--','linewidth',2); hold on;
    plot(cummin(log10(1e-12+results{6}.primal-optimal_dual)),'c','linewidth',2); hold on;
    plot(cummin(log10(1e-12+results{7}.primal-optimal_dual)),'g','linewidth',2); hold on;
    plot(cummin(log10(1e-12+results{8}.primal-optimal_dual)),'m','linewidth',2); hold on;
    plot(cummin(log10(1e-12+results{9}.primal-optimal_dual)),'m--','linewidth',2); hold off;
    %legend('mnp','cg-ls','cg-2/(t+1)','sgd-1/sqrt(t)','sgd-polyak','ellipsoid','simplex','accpm','Location','NorthEastOutside');
    set(gca,'fontsize',18)
    axis([0 maxiter   amin amax])
    xlabel('iterations');
    ylabel('log_{10}(F(A)-min(F))');
    
    pause
    
    % dual values
    plot(cummin(log10(1e-12-results{1}.dual+optimal_primal)),'k','linewidth',2); hold on;
    plot(cummin(log10(1e-12-results{2}.dual+optimal_primal)),'r','linewidth',2); hold on;
    plot(cummin(log10(1e-12-results{3}.dual+optimal_primal)),'r--','linewidth',2); hold on;
    plot(cummin(log10(1e-12-results{4}.dual+optimal_primal)),'b','linewidth',2); hold on;
    plot(cummin(log10(1e-12-results{5}.dual+optimal_primal)),'b--','linewidth',2); hold on;
    plot(cummin(log10(1e-12-results{6}.dual+optimal_primal)),'c','linewidth',2); hold on;
    plot(cummin(log10(1e-12-results{7}.dual+optimal_primal)),'g','linewidth',2); hold on;
    plot(cummin(log10(1e-12-results{8}.dual+optimal_primal)),'m','linewidth',2); hold on;
    plot(cummin(log10(1e-12-results{9}.dual+optimal_primal)),'m--','linewidth',2); hold off;
    legend('MNP','CG-LS','CG-2/(t+1)','SD-1/t^{1/2}','SD-Polyak','Ellipsoid','Simplex','ACCPM','ACCPM-simp.','Location','NorthEastOutside');
    axis([0 maxiter   amin amax])
    xlabel('iterations');
    ylabel('log_{10}(min(F)-s_-(V))');
    
    pause
end
