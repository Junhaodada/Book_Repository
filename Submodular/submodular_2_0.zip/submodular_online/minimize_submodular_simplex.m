function  [solution,certificate,duals,primals] = minimize_submodular_simplex(F,param_F,maxiter)
% Compute the minimizer of the submodular function using the simplex method
%
%
% INPUT
% F,param_F: submodular function
% maxiter: maximum number of iterations
% sfm: 1 if minimizing submodular function, 0 otherwise
%
% OUTPUT
% x: argmin. If sfm=1, then outputs the subset
% values of cost function
% gaps: certified optimaly gaps at each iteration



% compute upperbond on the maximum norm of all points (used in stopping
% critertion)
TOL = 1e-8;
n = param_F.p;

s = greedy_algo_submodular(randn(n,1),F,param_F);
Ialpha = find(s>=0);
Ibeta = find(s<0);
K = [];
S = s;

iter = 1;

while iter < maxiter
    % now perform the iteration
    k = length(K);
    i = size(S,2);
    T = [ ones(1,i);  S(K,:) ];
    
    eta = T \ [ 1; zeros(i-1,1) ];
    alpha = S(Ialpha,:) * eta;
    beta = -S(Ibeta,:) * eta;
    % check that alpha and beta are positive
    if any(alpha<-TOL) || any(beta<-TOL)
        disp('negative basic feasible solution');
        keyboard
    end
    temp = - ( T') \ (sum(S(Ibeta,:),1)');
    w = zeros(n,1);
    w(Ibeta) = 1;
    w(K) = temp(2:end);
    v = -temp(1);
    
    
    % first check that w in [0,1]^p
    [a0,b0]=min(w(K));
    [a1,b1]=max(w(K));
    
    if isempty(K) || ( (a0>=-TOL) && (a1<=1+TOL) )
        % w is in [0,1]^p: we then have a solution of the reduced problem
        
       
        
        %norm(w-wcvx)/norm(w)
        [news,Fvalues] = greedy_algo_submodular(w,F,param_F);
        %[newscvx,Fvalues] = greedy_algo_submodular(wcvx,F,param_F);
        %norm(news-newscvx)/norm(news)
        
        primals(iter) = min(Fvalues);
        duals(iter) = sum( min(S*eta,0));
        
        iter = iter + 1;
        
        % check optimality
        if (news'*w) <= v+TOL || (iter == maxiter),
            % OPTIMAL!
            
            break;
        end
        
        deta = - T \ [ 1; news(K) ];
        dalpha = news(Ialpha) + S(Ialpha,:) * deta;
        dbeta = -news(Ibeta) - S(Ibeta,:) * deta;
        indetapos = find( deta < -TOL );
        [ueta,ieta] = min( eta(indetapos) ./ ( - deta(indetapos) ) );
        indalphapos = find( dalpha < -TOL );
        [ualpha,ialpha] = min( alpha(indalphapos) ./ ( - dalpha(indalphapos) ) );
        indbetapos = find( dbeta < -TOL );
        [ubeta,ibeta] = min( beta(indbetapos) ./ ( - dbeta(indbetapos) ) );
        [a,b] = min([ueta,ualpha,ubeta]);
        
        switch b
            case 1, % an index in I gets out
                S(:,indetapos(ieta)) = [];
            case 2, % an index in Ialpha gets out
                K = [K, Ialpha(indalphapos(ialpha)) ];
                Ialpha(indalphapos(ialpha)) = [];
            case 3, % an index in Ialpha gets out
                K = [K, Ibeta(indbetapos(ibeta)) ];
                Ibeta(indbetapos(ibeta)) = [];
                
        end
        S = [S, news ];
    else
        % w is not in [0,1]^p
        if -a0 > a1-1
            % the negative ones are most violated
            i = K(b0); temp=zeros(length(K),1); temp(b0)=1;
            deta = T \ [ 0; temp ];
            dalpha = S(Ialpha,:) * deta;
            dbeta = -S(Ibeta,:) * deta;
            
            
            indetapos = find( deta < -TOL );
            [ueta,ieta] = min( eta(indetapos) ./ ( - deta(indetapos) ) );
            indalphapos = find( dalpha < -TOL );
            [ualpha,ialpha] = min( alpha(indalphapos) ./ ( - dalpha(indalphapos) ) );
            indbetapos = find( dbeta < -TOL );
            [ubeta,ibeta] = min( beta(indbetapos) ./ ( - dbeta(indbetapos) ) );
            [a,b] = min([ueta,ualpha,ubeta]);
            
            switch b
                case 1, % an index in I gets out
                    S(:,indetapos(ieta)) = [];
                case 2, % an index in Ialpha gets out
                    K = [K, Ialpha(indalphapos(ialpha)) ];
                    Ialpha(indalphapos(ialpha)) = [];
                case 3, % an index in Ialpha gets out
                    K = [K, Ibeta(indbetapos(ibeta)) ];
                    Ibeta(indbetapos(ibeta)) = [];
                    
            end
            Ialpha = [Ialpha; K(b0)];
            K(b0) = [];
            
        else
            % the positive ones are most violated
            
            
            i = K(b1); temp=zeros(length(K),1); temp(b1)=1;
            deta = -T \ [ 0; temp ];
            dalpha = S(Ialpha,:) * deta;
            dbeta = -S(Ibeta,:) * deta;
            
            
            indetapos = find( deta < -TOL );
            [ueta,ieta] = min( eta(indetapos) ./ ( - deta(indetapos) ) );
            indalphapos = find( dalpha < -TOL );
            [ualpha,ialpha] = min( alpha(indalphapos) ./ ( - dalpha(indalphapos) ) );
            indbetapos = find( dbeta < -TOL );
            [ubeta,ibeta] = min( beta(indbetapos) ./ ( - dbeta(indbetapos) ) );
            [a,b] = min([ueta,ualpha,ubeta]);
            
            switch b
                case 1, % an index in I gets out
                    S(:,indetapos(ieta)) = [];
                case 2, % an index in Ialpha gets out
                    K = [K, Ialpha(indalphapos(ialpha)) ];
                    Ialpha(indalphapos(ialpha)) = [];
                case 3, % an index in Ialpha gets out
                    K = [K, Ibeta(indbetapos(ibeta)) ];
                    Ibeta(indbetapos(ibeta)) = [];
                    
            end
            Ibeta = [Ibeta; K(b1)];
            K(b1) = [];
            
        end
        
        
    end
    
end

solution = w;
certificate = S*eta;

 