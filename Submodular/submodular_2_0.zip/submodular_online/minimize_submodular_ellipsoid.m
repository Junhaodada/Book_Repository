function [A,dual_variable,dual_values,best_primal_values,gaps,times]= minimize_submodular_ellipsoid(F,param_F,maxiter)
% find min_x in [0,1] f(x) using ellipsoid method
% also outputs dual certificates

if nargout>=6
    tic;
end

p = param_F.p;

% compute enclosing ball
B = sqrt(p)/2 * eye(p);
w = ones(p,1)/2;

%store for computing duality gap
ws{1} = w;
Bs{1} = single(B);
[s, Fvalues_loc] =  greedy_algo_submodular(w,F,param_F);
es{1} = s;
productive(1)=1;
values(1)= s'*w;
dual_variable = s;
dual_values(1) = sum( min(s,0));

best_primal_values(1) = min(Fvalues_loc);
 
bestvalue = Inf;
xbest = w;
skip = ceil( maxiter * p * p / 4e7 ); % decide how much to skip for storage of B
if nargout>=6
    times(1) = toc;
end

for iter =1:maxiter
    
    % update ellipsoid
    g =  s;
    Btg = B' * g;
    BBtg = B*Btg;
    nn = norm(Btg);
    w = w - 1/(p+1) * BBtg / nn;
    B = sqrt(p^2/ ( p^2 -1 )) * ( B  -  1/nn/nn*( 1- sqrt((p-1)/(p+1))) * BBtg*Btg');
    
    Bs{floor( 1 + iter /skip)} = single(B);
    ws{iter+1} = w;
    
    
    
    if any( w<=-1e-10 | w>=1+1e-10)
        % if infeasible ("non productive step")
        values(iter+1) = values(iter);
        best_primal_values(iter+1) = best_primal_values(iter);
        productive(iter+1) = 0;
        % build a separator
        s = zeros(p,1);
        a = find(w<=-1e-10);
        if isempty(a)
            b = find(w>=1+1e-10);
            s(b(1))= 1;
        else
            s(a(1)) = -1;
        end
        
        
        
        
    else
        % if feasible ("productive step")
        
        [s,Fvalues_loc,order] = greedy_algo_submodular(w,F,param_F);
        [a,b] = min(Fvalues_loc);
        if min(a,0) < bestvalue
            if a < 0
                % allow empty set to be optimal
                Aopt = order(1:b);
                bestvalue = a;
            else
                bestvalue = 0;
                Aopt = [];
            end
        end
        values(iter+1) = s'*w;
        best_primal_values(iter+1) = min(Fvalues_loc);
        productive(iter+1) = 1;
        
        
    end
    
    es{iter+1} = s;
    
    
    % now compute dual values using Nemirovski's paper
    [uu,ss,vv] = svd(B);
    [temp, iopt ]  = min(diag(ss));
    h = uu(:,iopt);
    lambdas = zeros(1,iter);
    mus = zeros(1,iter);
    
    g = h;
    a = - h'* w;
    for t=iter:-1:1
        pp = double(Bs{1+floor((t-1)/skip)})'* g;
        qq = double(Bs{1+floor((t-1)/skip)})'* es{t};
        lambdas(t) = max( (pp'* qq) / (qq' * qq ) , 0 );
        g = g - lambdas(t) * es{t};
        a = a + lambdas(t) * es{t}' * ws{t};
    end
    
    g = -h;
    a = + h'* w;
    for t=iter:-1:1
        pp = double(Bs{1+floor((t-1)/skip)})'* g;
        qq = double(Bs{1+floor((t-1)/skip)})'* es{t};
        mus(t) = max( (pp'* qq) / (qq' * qq ) , 0 );
        g = g - mus(t) * es{t};
        a = a + mus(t) * es{t}' * ws{t};
    end
    
    
    xi = (lambdas + mus) / ( sum(lambdas(productive(1:iter)==1))+sum(mus(productive(1:iter)==1)));
    
    xi = xi((productive(1:iter)==1));
    Es = cell2mat(es(productive(1:iter)==1));
    dual_variable = Es * xi';
    dual_values(iter+1) = sum( min(dual_variable,0));
    gap = min(values) - max(dual_values);
     
    if nargout>=6
        times(iter+1) = toc;
    end
    
    
end
gaps = -dual_values+ best_primal_values;

% A = find( w >=0 );
A = Aopt;


