function [primal_variable,dual_variable, dual_values, primal_values ] = minimize_submodular_accpm(F,param_F,maxiter,gap)
% minimize submodular function by ACCPM


if nargin<4
    gap = 1e-6;
end

n = param_F.p;


% use random initialization of permutation
w = rand(n,1);
S = greedy_algo_submodular(w,F,param_F);
u = 0;
eta = 1;


iter = 0;
while iter < maxiter
    iter = iter + 1;
    
    
    alpha = 1;
    beta = 1;
    epsilon_newton = 1e-12;
    maxiter_newton = 100;
    [eta, lambda2, iter_newton] = accpm_submodular_step(eta,u,S,alpha,beta,epsilon_newton,maxiter_newton);
    s = beta * ( S*eta);
    w = .5  - .5 * s ./ ( 1 + sqrt(1+s.*s));
    
    [news,Fvalues] = greedy_algo_submodular(w,F,param_F);
    u = min(u,  min(Fvalues) );
    s = S*eta/sum(eta);
    
    dual_values(iter) = sum(min(s,0));
    primal_values(iter) = u;
    gaps(iter) = primal_values(iter) - dual_values(iter);
    S = [ S, news];
    eta = [ eta; 1];
    if gaps(iter) < gap, break; end
end
primal_variable = w;
dual_variable = s;
 