function [A,value] = compute_dual_norm_tree(s,tree,weights,order,children);
% compute dual norm for tree-based submodular function
% using divide and conquer strategy

[ng,p] = size(tree);
if ng==0
    A = [];
    value = 0;
    return;
else


    if p==1
        A=[];
        value = weights/s;

    else
        beta = ( weights'*max(tree,[],2) ) / sum(s);
        A = minimize_submod_tree(tree,weights,order,children,beta*s);

        if isempty(A)
            A=1:p;
        end
        if length(A)==p
            
            value = beta;
            A = 1:p;

        else

            Ac = 1:p; Ac(A) = [];




            % create new tree-structured groups with appropriate weights
            tree0 = tree(:,A);
            [B,I,J ] = unique(tree0,'rows');

            weights0 = sparse(J,1:ng,ones(ng,1),max(J),ng) * weights;
            % remove empty groups
            ind = find(~any(B,2));
            weights0(ind) = [];
            tree0 = B;
            tree0(ind,:) = [];

            % isolate non-penalized note
            ind = find(any(tree0,1));
            indc = 1:length(A);
            indc(ind) = [];

            [order0,children0 ] = get_children_order(tree0(:,ind));
            [w0, value] = compute_dual_norm_tree(s(A(ind)),tree0(:,ind),weights0,order0,children0);

            A = A(w0);
            
             
        end

    end


end


%%%%%%%%%%%%%%%%%%%%%%%%%
function          [order,children ] = get_children_order(tree);
[ng,p] = size(tree);
% build dag
dag = sparse(logical(zeros(ng)));
stree = sum( tree,2 );
for i=1:ng
    dag(i,   sum( tree(:,tree(i,:)),2 ) == stree ) = 1;
end
dag = dag - diag(diag(dag));
% build order
dag_loc = dag;
order = [];
lefttoorder = 1:ng;
while ~isempty(lefttoorder)
    roots = ~any(dag_loc,1);
    order = [ lefttoorder(roots), order ];
    lefttoorder( roots) = [];
    dag_loc(roots,:) = [];
    dag_loc(:,roots) = [];
end

% build children
children = sparse(logical(zeros(ng)));
for i=1:ng
    anc = order(i+min(find(dag(order(i+1:end),order(i)))));
    children(anc,order(i))=1;
end


   