function  [w,etat,duals,primals,Sindices] = minimize_submodular_simplex_generic(SS,maxiter)
% Compute the minimizer of the submodular function using the simplex method
% directly on the extreme points
%
 


% compute upperbond on the maximum norm of all points (used in stopping
% critertion)
TOL = 1e-8;
n = size(SS,1);

t = randperm(size(SS,2));
Sindices = t(1);
s = SS(:,t(1));
Ialpha = find(s>=0);
Ibeta = find(s<0);
K = [];

iter = 1;

while iter < maxiter
    % now perform the iteration
    k = length(K);
    i = length(Sindices);
    T = [ ones(1,i);  SS(K,Sindices) ];
    
    eta = T \ [ 1; zeros(i-1,1) ];
    alpha = SS(Ialpha,Sindices) * eta;
    beta = -SS(Ibeta,Sindices) * eta;
    % check that alpha and beta are positive
    if any(alpha<-TOL) || any(beta<-TOL)
        disp('negative basic feasible solution');
        keyboard
    end
    temp = - ( T') \ (sum(SS(Ibeta,Sindices),1)');
    w = zeros(n,1);
    w(Ibeta) = 1;
    w(K) = temp(2:end);
    v = -temp(1);
    
    
    % first check that w in [0,1]^p
    [a0,b0]=min(w(K));
    [a1,b1]=max(w(K));
    
    if isempty(K) || ( (a0>=-TOL) && (a1<=1+TOL) )
        % w is in [0,1]^p: we then have a solution of the reduced problem
        
         
        %norm(w-wcvx)/norm(w)
        [a,b] = max(SS'*w);
        newsindices = b;
        news = SS(:,b);
        %[newscvx,Fvalues] = greedy_algo_submodular(wcvx,F,param_F);
        %norm(news-newscvx)/norm(news)
        
        primals(iter) = a;
        duals(iter) = sum( min(SS(:,Sindices)*eta,0));
        
        iter = iter + 1;
        
        % check optimality
        if (news'*w) <= v+TOL || (iter == maxiter),
            % OPTIMAL!
            
            break;
        end
        
        deta = - T \ [ 1; news(K) ];
        dalpha = news(Ialpha) + SS(Ialpha,Sindices) * deta;
        dbeta = -news(Ibeta) - SS(Ibeta,Sindices) * deta;
        indetapos = find( deta < -TOL );
        [ueta,ieta] = min( eta(indetapos) ./ ( - deta(indetapos) ) );
        indalphapos = find( dalpha < -TOL );
        [ualpha,ialpha] = min( alpha(indalphapos) ./ ( - dalpha(indalphapos) ) );
        indbetapos = find( dbeta < -TOL );
        [ubeta,ibeta] = min( beta(indbetapos) ./ ( - dbeta(indbetapos) ) );
        [a,b] = min([ueta,ualpha,ubeta]);
        
        switch b
            case 1, % an index in I gets out
                Sindices(indetapos(ieta)) = [];
             case 2, % an index in Ialpha gets out
                K = [K, Ialpha(indalphapos(ialpha)) ];
                Ialpha(indalphapos(ialpha)) = [];
            case 3, % an index in Ialpha gets out
                K = [K, Ibeta(indbetapos(ibeta)) ];
                Ibeta(indbetapos(ibeta)) = [];
                
        end
        Sindices = [Sindices, newsindices ];
    else
        % w is not in [0,1]^p
        if -a0 > a1-1
            % the negative ones are most violated
            i = K(b0); temp=zeros(length(K),1); temp(b0)=1;
            deta = T \ [ 0; temp ];
            dalpha = SS(Ialpha,Sindices) * deta;
            dbeta = -SS(Ibeta,Sindices) * deta;
            
            
            indetapos = find( deta < -TOL );
            [ueta,ieta] = min( eta(indetapos) ./ ( - deta(indetapos) ) );
            indalphapos = find( dalpha < -TOL );
            [ualpha,ialpha] = min( alpha(indalphapos) ./ ( - dalpha(indalphapos) ) );
            indbetapos = find( dbeta < -TOL );
            [ubeta,ibeta] = min( beta(indbetapos) ./ ( - dbeta(indbetapos) ) );
            [a,b] = min([ueta,ualpha,ubeta]);
            
            switch b
                case 1, % an index in I gets out
                    Sindices(indetapos(ieta)) = [];
                 case 2, % an index in Ialpha gets out
                    K = [K, Ialpha(indalphapos(ialpha)) ];
                    Ialpha(indalphapos(ialpha)) = [];
                case 3, % an index in Ialpha gets out
                    K = [K, Ibeta(indbetapos(ibeta)) ];
                    Ibeta(indbetapos(ibeta)) = [];
                    
            end
            Ialpha = [Ialpha; K(b0)];
            K(b0) = [];
            
        else
            % the positive ones are most violated
            
            
            i = K(b1); temp=zeros(length(K),1); temp(b1)=1;
            deta = -T \ [ 0; temp ];
            dalpha = SS(Ialpha,Sindices) * deta;
            dbeta = -SS(Ibeta,Sindices) * deta;
            
            
            indetapos = find( deta < -TOL );
            [ueta,ieta] = min( eta(indetapos) ./ ( - deta(indetapos) ) );
            indalphapos = find( dalpha < -TOL );
            [ualpha,ialpha] = min( alpha(indalphapos) ./ ( - dalpha(indalphapos) ) );
            indbetapos = find( dbeta < -TOL );
            [ubeta,ibeta] = min( beta(indbetapos) ./ ( - dbeta(indbetapos) ) );
            [a,b] = min([ueta,ualpha,ubeta]);
            
            switch b
                case 1, % an index in I gets out
                    Sindices(indetapos(ieta)) = [];
                 case 2, % an index in Ialpha gets out
                    K = [K, Ialpha(indalphapos(ialpha)) ];
                    Ialpha(indalphapos(ialpha)) = [];
                case 3, % an index in Ialpha gets out
                    K = [K, Ibeta(indbetapos(ibeta)) ];
                    Ibeta(indbetapos(ibeta)) = [];
                    
            end
            Ibeta = [Ibeta; K(b1)];
            K(b1) = [];
            
        end
        
        
    end
    
end
etat = zeros(size(SS,2),1);
etat(Sindices) = eta;