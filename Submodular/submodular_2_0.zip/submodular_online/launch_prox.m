function [primal,dual,solution,certificate,primal_nopav] = launch_prox(dataset,method,maxiter,seed,gap);

% launch sfm for some dataset and some method
if nargin<5, gap = 1e-8; end
% load data
[F,param_F] = load_data_submodular(dataset,seed);

switch method
    
    case 1, % MIN NORM POINT
        [solution,certificate,dual,primal,gaps,primal_nopav] = minimize_submodular_FW_minnormpoint(F,param_F,maxiter,0,gap);
        
    case 2, % conditional gradient - line search
        [solution,certificate,dual,primal,gaps,primal_nopav] = minimize_submodular_FW_condgradient(F,param_F,maxiter,0);
        
    case 3, % conditional gradient - no line search (fixed schedule)
        [solution,certificate,dual,primal,gaps,primal_nopav] = minimize_submodular_FW_condgradient_nolinesearch(F,param_F,maxiter,0);
        
            
end


