function [x,Fvalues] = greedy_algo_submodular_s(I,F,param_F);
% greedy algorithm started from ordering
n = length(I);
x = zeros(n,1);  
Fvalues = zeros(n,1);
Fvalues(1) = F(I(1),param_F);
x(I(1)) = Fvalues(1);
for i=2:n,
    Fvalues(i) = F(I(1:i),param_F);
    x(I(i)) = Fvalues(i) - Fvalues(i-1);
end
