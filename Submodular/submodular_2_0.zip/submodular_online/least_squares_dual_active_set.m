function [w,primals,duals,gaps,times] = least_squares_dual_active_set(y,X,F,param_F,lambda,maxiter,gap);
% solve the least-square problems for trees
% using a dual active set (unstable in higher dimensions)

if nargin<8,
    gap = 1e-12;
end

if nargout>4
    tic
end

% preprocess X
[n p] = size(X);
[UX,sX,VX] = svd(X,'econ');
ind = find(diag(sX)>1e-10);
UX = UX(:,ind);
sX = diag(sX(ind,ind));
VX = VX(:,ind);
VXorth = null(VX');


% initialization

alpha = zeros(n,1);
S = zeros(p,1);
eta=lambda;
w = VX*diag(1./sX)*UX'*y;
c = 0;

for iter = 1:maxiter
    
    % check_optimality
    s = sign(w) .* greedy_algo_submodular(abs(w),F,param_F);
    
    
    
    
    % compute duality gaps
    primals(iter) = .5/n*(y-X*w)'*(y-X*w) + lambda * s'*w;
    duals(iter) = alpha'*y - n/2 * alpha'*alpha;
    gaps(iter) = primals(iter)-duals(iter);
     if nargout>4
        times(iter)=toc;
    end
    
    
    
    if gaps(iter) < gap
        % optimality!
        break;
    end
    
    
    if s'* w < c,
        % optimality!
        break;
    end
    
    S = [ S, s ];
    
    
    
    % compute new candidate
    eta = [eta; 0];
    
    
    
    
    
    b = [1/n*X'*y; zeros(size(S,2),1); -lambda ];
    
    A=[ 1/n*X'*X, S, zeros(p,1) ; ...
        S', zeros(size(S,2)), -ones(size(S,2),1); ...
        zeros(1,p), -ones(1,size(S,2)), 0 ];
    A=(A+A')/2;
    
    % direct way
    temp1 = A\b;
    test1 = norm(A*temp1 - b);
    temp = temp1;
%     % semi-robust way to solve A\b
%     [u,e]=eig(A);
%     ind = find(abs(diag(e))>1e-10* max(diag(e)));
%     temp2 = u(:,ind) *  diag(1./diag(e(ind,ind))) * ( u(:,ind)' * b ) ;
%     test2=norm(A*temp2 - b);
%     
%     temp3 = cgs(A,b,1e-16,100,[],[],temp2);
%     test3=norm(A*temp3 - b);
%     [test1 test2 test3]
%     pause
%     [a,bb]=min([test1 test2 test3]);
%     if bb==1
%         temp = temp1;
%     else
%         temp = temp2;
%     end
%     test = norm(A*temp - b)
%     if test>1e-6
%         keyboard
%     end
    wnew = temp(1:p);
    etanew = temp(p+1:p+size(S,2));
    cnew = temp(end);
    
    
    %
    
    
     
    while any( etanew <= -1e-8*lambda )
        ind = find( etanew <= -1e-8*lambda);
        [a,b] = min( eta(ind)./(eta(ind)-etanew(ind)) );
        toremove = ind(b);
        eta = eta + a*(etanew-eta);
        % toremove = find(eta<1e-10*lambda); % remove potentially more ->
        % makes the algorothm unstable
        eta(toremove) = [];
        S(:,toremove) = [];
        
        
        
        b = [1/n*X'*y; zeros(size(S,2),1); -lambda ];
        
        A=[ 1/n*X'*X, S, zeros(p,1) ; ...
            S', zeros(size(S,2)), -ones(size(S,2),1); ...
            zeros(1,p), -ones(1,size(S,2)), 0 ];
        A=(A+A')/2;
        
         % direct way
    temp1 = A\b;
    test1 = norm(A*temp1 - b);
    temp = temp1;
%     % semi-robust way to solve A\b
%     [u,e]=eig(A);
%     ind = find(abs(diag(e))>1e-10* max(diag(e)));
%     temp2 = u(:,ind) *  diag(1./diag(e(ind,ind))) * ( u(:,ind)' * b ) ;
%     test2=norm(A*temp2 - b);
%     
%     temp3 = cgs(A,b,1e-16,100,[],[],temp2);
%     test3=norm(A*temp3 - b);
%     [test1 test2 test3]
%     pause
%     [a,bb]=min([test1 test2 test3]);
%     if bb==1
%         temp = temp1;
%     else
%         temp = temp2;
%     end
%     test = norm(A*temp - b)
%     if test>1e-6
%         keyboard
%     end
        wnew = temp(1:p);
        etanew = temp(p+1:p+size(S,2));
        cnew = temp(end);
    end
    
    eta = etanew;
    w = wnew;
    c = cnew;
    alpha = 1/n*(y - X*w);
    
end
