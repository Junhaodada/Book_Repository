function [primal_variable,dual_variable, dual_values,best_primal_values,gaps,times] = minimize_submodular_accpm(F,param_F,maxiter,gap)


if nargout>=6
    tic;
end

n = param_F.p;




% use random initialization of permutation
w = rand(n,1);
S = greedy_algo_submodular(w,F,param_F);
tmax = w'*S;
t = tmax;


iter = 0;
while iter < maxiter
    iter = iter + 1;
    
    
    if 1
        % finds analytic center
        A = [ - eye(n), zeros(n,1) ; ...
            eye(n), zeros(n,1); ...
            S', ones(size(S,2),1) ; ...
            zeros(1,n), 1 ; ];
        b = [ zeros(n,1); ones(n,1); zeros(size(S,2),1); tmax ];
        
        x = [w; t];
        
        
        %[x_star, H, niter] = analytic_center(A,b,x);
        %keyboard
        
%         y = max(b - A*x + 1e-2,0);
%         y(find(y==0))=1;
%         
%         
%         alpha = 0.01;
%         beta = 0.5;
%         epsilon = 1e-6;
%         maxiter = 50;
%         nu = y*0;
%         for iterac = 1:maxiter
%             
%             % direction
%             g = -1./y;
%             rp = y + A*x - b;
%             rd = [A'*nu;  g+nu];
%             H = diag( 1./y./y);
%             Dx = (A'*H*A) \ ( A'*g - A'*H*rp);
%             Dy = - A*Dx - rp;
%             Dnu = - H*Dy - g - nu;
%             % temp = - [ zeros(size(A,2)), zeros(size(A,2),length(y)), A'; ...
%             %     zeros(length(y),size(A,2)), H, eye(size(A,1)); ...
%             %     A, eye(size(A,1)), zeros(size(A,1))] \ [ rd; rp];
%             % norm([Dx; Dy; Dnu] -temp)
%             tt = 1;
%             while any(y+tt*Dy <1e-10), tt = tt*beta; end
%             
%             while norm([ y+tt*Dy + A*(x+tt*Dx) - b; A'*(nu+tt*Dnu);  -1./(y+tt*Dy)+nu+tt*Dnu ] ) > ( 1 - alpha*tt) * norm([ y + A*x - b; A'*nu;  g+nu ] ), tt = tt*beta; end
%             
%             %           norm([ y+ Dy + A*(x+Dx) - b; A'*(nu+Dnu);  -1./(y+Dy)+nu+Dnu ] ) / norm([ y + A*x - b; A'*nu;  g+nu ] )
%             %           norm([ y+ Dy/10 + A*(x+Dx/10) - b; A'*(nu+Dnu/10);  g+nu+Dnu/10 ] ) / norm([ y + A*x - b; A'*nu;  g+nu ] )
%             
%             x = x+tt*Dx;
%             y = y+tt*Dy;
%             nu = nu+tt*Dnu;
%             if norm([ y + A*x - b; A'*nu;  (-1./y)+nu ] ) < epsilon, break; end
%             
%         end
        
        x_star  = analytic_center(A,b,x);
        x_star = acent_feas(A,b,x_star)
        keyboard
        w = x_star(1:end-1);
        t = x_star(end);
    else
         
        % CVX
        cvx_quiet(true);
        cvx_solver sdpt3;
        cvx_precision default;
        
        cvx_begin
        variable w(n);
        variable t(1);
        minimize( sum(-log(w)) + sum(-log(1-w)) + sum(-log(tmax-t)) + sum(-log(t-S'*w)));
        cvx_end
        sum(-log(w)) + sum(-log(1-w)) + sum(-log(tmax-t)) + sum(-log(t-S'*w))
    end
    
     sum(repmat(-1./(b-A*x_star),1,size(A,2)) .* A,1)
     
    w
    pause
    news = greedy_algo_submodular(w,F,param_F);
    tmax =  news'*w;
    S = [ S, news];
    
    
    
    if nargout>=6
        times(iter) = toc;
    end
    
    
end
keyboard
primal_variable = w;
