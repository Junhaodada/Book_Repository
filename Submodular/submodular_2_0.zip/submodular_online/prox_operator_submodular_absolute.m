function [w,bundle] = prox_operator_submodular_absolute(z,lambda,F,param_F,gap,bundle);
% minimize lambda * f(|w|) + .5 * || w - z ||^2
% using the proximal operator for f(w) and then "projecting"

if nargin<5, gap = 1e-8; end
signs = sign(z);
z = abs(z);
if nargin==6
    [w,bundle] = prox_operator_submodular(z,lambda,F,param_F,gap,bundle);
else
    [w,bundle]= prox_operator_submodular(z,lambda,F,param_F,gap);
end
w = max(w,0) .* signs;

