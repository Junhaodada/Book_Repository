for dataset = 1:4
    switch dataset
        case 1
            amax=6;
            amin=-2;
            maxiter = 1000;
            name='genrmflong';
            for i=1:3
                maxiter = 2000;
                gap = 1e-12;
                [primal,dual,solution,certificate,primal_nopav] = launch_prox(dataset,1,maxiter,1,gap);
                results{i}.primal = primal;
                results{i}.dual = dual;
                results{i}.solution = solution;
                results{i}.certificate  = certificate;
                results{i}.primal_nopav  = primal_nopav;
            end
        case 2
            amax=8;
            amin=0;
            maxiter = 1500;
            name='genrmfwide';
            for i=1:3
                maxiter = 2000;
                gap = 1e-12;
                [primal,dual,solution,certificate,primal_nopav] = launch_prox(dataset,1,maxiter,1,gap);
                results{i}.primal = primal;
                results{i}.dual = dual;
                results{i}.solution = solution;
                results{i}.certificate  = certificate;
                results{i}.primal_nopav  = primal_nopav;
            end
        case 3
            amax=2;
            amin=-5;
            maxiter = 650;
            name='twomoons';
            for i=1:3
                maxiter = 2000;
                gap = 1e-12;
                [primal,dual,solution,certificate,primal_nopav] = launch_prox(dataset,1,maxiter,1,gap);
                results{i}.primal = primal;
                results{i}.dual = dual;
                results{i}.solution = solution;
                results{i}.certificate  = certificate;
                results{i}.primal_nopav  = primal_nopav;
            end
            
        case 4
            amax=3;
            amin=-4.5;
            maxiter = 400;
            name='bilmes';
            for i=1:3
                maxiter = 2000;
                gap = 1e-12;
                [primal,dual,solution,certificate,primal_nopav] = launch_prox(dataset,1,maxiter,1,gap);
                results{i}.primal = primal;
                results{i}.dual = dual;
                results{i}.solution = solution;
                results{i}.certificate  = certificate;
                results{i}.primal_nopav  = primal_nopav;
            end
    end
    optimal_dual = -Inf;
    optimal_primal = Inf;
    min_dual = Inf;
    max_primal = -Inf;
    max_gap = 0;
    for j=1:3
        optimal_dual = max(optimal_dual, max(results{j}.dual));
        optimal_primal = min(optimal_primal, min(results{j}.primal));
        min_dual = min( min_dual, min(results{j}.dual));
        max_primal = max( max_primal, max(results{j}.primal_nopav));
        max_gap = max( max_gap, max(results{j}.primal-results{j}.dual));
    end
    
    % primal values
    hold off
    plot(cummin(log10(1e-12+results{1}.primal-optimal_primal)),'k','linewidth',2); hold on;
    plot(cummin(log10(1e-12+results{2}.primal-optimal_primal)),'r','linewidth',2); hold on;
    plot(cummin(log10(1e-12+results{3}.primal-optimal_primal)),'b','linewidth',2); hold on;
    plot(cummin(log10(1e-12+results{1}.primal_nopav-optimal_primal)),'k--','linewidth',2); hold on;
    plot(cummin(log10(1e-12+results{2}.primal_nopav-optimal_primal)),'r--','linewidth',2); hold on;
    plot(cummin(log10(1e-12+results{3}.primal_nopav-optimal_primal)),'b--','linewidth',2); hold off;
    %legend('mnp','cg-ls','cg-1/t','sgd-1/sqrt(t)','sgd-polyak','ellipsoid','simplex','accpm','Location','NorthEastOutside');
    set(gca,'fontsize',18)
    axis([0 maxiter   amin amax ])
    xlabel('iterations');
    ylabel('log_{10}( ||w||^2/2+f(w)-OPT)');
    
    pause
    
    % dual values
    hold off
    plot(cummin(log10(1e-12-results{1}.dual+optimal_primal)),'k','linewidth',2); hold on;
    plot(cummin(log10(1e-12-results{2}.dual+optimal_primal)),'r','linewidth',2); hold on;
    plot(cummin(log10(1e-12-results{3}.dual+optimal_primal)),'b','linewidth',2); hold on;
    legend('MNP','CG-LS','CG-2/(t+1)','Location','NorthEastOutside');
    axis([0 maxiter   amin amax])
    xlabel('iterations');
    ylabel('log_{10}(OPT+ ||s||^2/2)');
    pause
    
end
