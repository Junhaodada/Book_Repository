function w = prox_operator_submodular_absolute_tree(z,lambda,tree,weights,order,children);
% minimize lambda * f(|w|) + .5 * || w - z ||^2
% for tree functions, using a divide-and-conquer strategy
% Algorithm on the base polyhedron followed by "projection" back to |P|(F)


signs = sign(z);
z = abs(z);
w = prox_operator_submodular_tree(z,lambda,tree,weights,order,children);
w = max(w,0) .* signs;

