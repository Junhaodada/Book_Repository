function f = submodular_fct_iwata(A,param)
% Iwata's test function
if isempty(A), f=0; else
    n = length(A);
    f = n * ( param.p - n ) - 5 * sum(A ) + 2*n*param.p;
    
end

