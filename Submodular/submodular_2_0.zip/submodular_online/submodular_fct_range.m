function F = submodular_fct_range(A,param_F);
% submodular function computing the range of the data
if isempty(A),
    F=0;
else
    F = max(A)- min(A) + param_F.p - 1;
end
F = F + param_F.weight_L1 * length(A);
