function A = minimize_submod_tree(tree,weights,order,children,t);
% minimize a tree-based submodular function minus a modular function
% using a single traversal of the tree
% could me implemented much better...
[ng,p] = size(tree);
tt = zeros(ng,1);
roots = zeros(ng,1);
for i=order
    
    ind = find( tree(i,:) & ( ~isnan(t)' ));
    if ~isempty(ind)
        tt(i) = t(ind);
        roots(i) = ind;
        t(ind) = NaN;
    end
end

psis = sparse(zeros(ng,1));
x = zeros(p,1);
 for i = order
    if tt(i) >= 0 & ( roots(i)>0)
        temp1 = -tt(i) + weights(i) + children(i,:) * psis;
        if temp1 <= 1e-12
            psis(i) = temp1;
            x(roots(i))=1;
        else
            psis(i) =  0;
            x(tree(i,:))=0;
        end
    else
        temp2 = weights(i) + children(i,:) * psis;
        if temp2 <= 1e-12
            psis(i) = temp2;
        else
            psis(i) =  0;
            x(tree(i,:))=0;
        end
    end
 end
A = find(x==1);
