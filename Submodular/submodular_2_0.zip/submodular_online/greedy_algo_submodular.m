function [x,Fvalues,I] = greedy_algo_submodular(w,F,param_F);
% greedy algorithm started w
n = length(w);
x = zeros(n,1); [temp,I] = sort(w,'descend');
Fvalues = zeros(n,1);
Fvalues(1) = F(I(1),param_F);
x(I(1)) = Fvalues(1);
for i=2:n,
    Fvalues(i) = F(I(1:i),param_F);
    x(I(i)) = Fvalues(i) - Fvalues(i-1);
end
