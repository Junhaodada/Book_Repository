function f = submodular_fct_trees(A,param);
% tree-based submodular function
x = sparse(zeros(param.p,1)); x(A)=1;
f = param.weights'*max(param.tree(:,A),[],2);