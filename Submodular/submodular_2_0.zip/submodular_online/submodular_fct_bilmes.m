function F = submodular_fct_bilmes(A,param_F);
% submodular function used in the speech example given by Jeff Bilmes group
F = - length(A) + param_F.lambda * (full(sum(any(param_F.W(A,:)))) ) ^ param_F.alpha;
