function [beta,primals,duals,gaps,times] = least_squares_tree(y,X,tree,weights,order,children,maxiter,gap);
% solve the least-square problems for trees
% using a primal active-set method

if nargin<8,
    gap = 1e-12;
end

[n p] = size(X);

% initialization
Z = [];
Zbeta = [];
beta = zeros(p,1);
eta = 0;

if nargout>4
    tic
end

for iter = 1:maxiter
    
    % check_optimality
    s = X'*(y-X*beta);
    [A,value] = compute_dual_norm_tree(abs(s),tree,weights,order,children);
    xx = sparse(zeros(p,1)); xx(A)=1;
    f =  weights'*max(tree(:,A),[],2);
    w = zeros(p,1);
    w(A) = 1/f;
    w = w .* sign(s);
    
    
    % compute duality gaps
    primals(iter) = .5/n*(y-X*beta)'*(y-X*beta) + sum(eta);
    alpha = (y - X*beta)*value;
    duals(iter) = alpha'*y - n/2 * alpha'*alpha;
    gaps(iter) = primals(iter)-duals(iter);
    
    
    if nargout>4
        times(iter)=toc;
    end
    
    
    
    if gaps(iter) < gap
        % optimality!
        break;
    end
    
    
    if 1/value < n,
        % optimality!
        break;
    end
    
    Z = [ Z, X*w ];
    Zbeta = [ Zbeta, w];
    
    % compute new candidate
    eta = [eta; 0];
    zeta = (Z'*Z) \ ( Z'*y - n );
    
    while any( zeta<= -1e-12 )
        ind = find( zeta <= -1e-12);
        [a,b] = min( eta(ind)./(eta(ind)-zeta(ind)) );
        toremove = ind(b);
        eta = eta + a*(zeta-eta);
        toremove = find(eta<1e-12); % remove potentially more
        eta(toremove) = [];
        Z(:,toremove) = [];
        Zbeta(:,toremove) = [];
        zeta = (Z'*Z) \ ( Z'*y - n );
    end
    
    eta = zeta;
    beta = Zbeta * eta;
end
