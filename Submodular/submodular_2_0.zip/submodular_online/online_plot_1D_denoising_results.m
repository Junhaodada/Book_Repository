% PLOT DENOISING RESULTS ON 1D SIGNALS
% 3 different plots
 
subplot(1,4,3)
[xs,z0,z] = get_denoising_result(1,1,64,.1,1,.075)
plot(z0,'r','linewidth',2); hold on;
plot(z,'r','linewidth',1); hold on;
plot(xs,'k','linewidth',2); hold off
set(gca,'fontsize',18)
axis([1 64 -.5 2.5])
title('L_{\infty}-relaxation')

subplot(1,4,2)
[xs,z0,z] = get_denoising_result(1,13,64,.1,1,.75)
plot(z0,'r','linewidth',2); hold on;
plot(z,'r','linewidth',1); hold on;
plot(xs,'k','linewidth',2); hold off
set(gca,'fontsize',18)
axis([1 64 -.5 2.5])
title('Laplacian + L_1')

subplot(1,4,4)
[xs,z0,z] = get_denoising_result(1,2,64,.1,1,.2)
plot(z0,'r','linewidth',2); hold on;
plot(z,'r','linewidth',1); hold on;
plot(xs,'k','linewidth',2); hold off
set(gca,'fontsize',18)
axis([1 64 -.5 2.5])
title('L_{2}-relaxation')

subplot(1,4,1)
[xs,z0,z] = get_denoising_result(1,11,64,.1,1,.5)
plot(z0,'r','linewidth',2); hold on;
plot(z,'r','linewidth',1); hold on;
plot(xs,'k','linewidth',2); hold off
set(gca,'fontsize',18)
axis([1 64 -.5 2.5])
title('TV + L_1')








 
open('denoising_results.fig');
subplot(1,4,3)
[xs,z0,z] = get_denoising_result(2,1,64,.2,1,.075)
plot(z0,'r','linewidth',2); hold on;
plot(z,'r','linewidth',1); hold on;
plot(xs,'k','linewidth',2); hold off
set(gca,'fontsize',18)
axis([1 64 -2.5 2.5])
title('L_{\infty}-relaxation')

subplot(1,4,2)
[xs,z0,z] = get_denoising_result(2,13,64,.2,1,.75)
plot(z0,'r','linewidth',2); hold on;
plot(z,'r','linewidth',1); hold on;
plot(xs,'k','linewidth',2); hold off
set(gca,'fontsize',18)
axis([1 64 -2.5 2.5])
title('Laplacian + L_1')

subplot(1,4,4)
[xs,z0,z] = get_denoising_result(1,4,64,.2,1,.2)
plot(z0,'r','linewidth',2); hold on;
plot(z,'r','linewidth',1); hold on;
plot(xs,'k','linewidth',2); hold off
set(gca,'fontsize',18)
axis([1 64 -2.5 2.5])
title('L_{2}-relaxation')

subplot(1,4,1)
[xs,z0,z] = get_denoising_result(2,11,64,.2,1,.5)
plot(z0,'r','linewidth',2); hold on;
plot(z,'r','linewidth',1); hold on;
plot(xs,'k','linewidth',2); hold off
set(gca,'fontsize',18)
axis([1 64 -2.5 2.5])
title('TV + L_1')

 







 
open('denoising_results.fig');
subplot(1,4,3)
[xs,z0,z] = get_denoising_result(3,1,64,.2,1,.095)
plot(z0,'r','linewidth',2); hold on;
plot(z,'r','linewidth',1); hold on;
plot(xs,'k','linewidth',2); hold off
set(gca,'fontsize',18)
axis([1 64 -.5 4])
title('L_{\infty}-relaxation')

subplot(1,4,2)
[xs,z0,z] = get_denoising_result(3,13,64,.2,1,.95)
plot(z0,'r','linewidth',2); hold on;
plot(z,'r','linewidth',1); hold on;
plot(xs,'k','linewidth',2); hold off
set(gca,'fontsize',18)
axis([1 64 -.5 4])
title('Laplacian + L_1')

subplot(1,4,4)
[xs,z0,z] = get_denoising_result(3,2,64,.2,1,.2)
plot(z0,'r','linewidth',2); hold on;
plot(z,'r','linewidth',1); hold on;
plot(xs,'k','linewidth',2); hold off
set(gca,'fontsize',18)
axis([1 64 -.5 4])
title('L_{2}-relaxation')

subplot(1,4,1)
[xs,z0,z] = get_denoising_result(3,11,64,.2,1,.5)
plot(z0,'r','linewidth',2); hold on;
plot(z,'r','linewidth',1); hold on;
plot(xs,'k','linewidth',2); hold off
set(gca,'fontsize',18)
axis([1 64 -.5 4])
title('TV + L_1')






 



