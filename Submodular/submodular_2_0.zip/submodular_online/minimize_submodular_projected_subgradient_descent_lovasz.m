function [x_primal,x_dual,dual_values,primal_values,gaps,added1,added2,added3]  = minimize_submodular_projected_subgradient_descent_lovasz(F,param_F,maxiter)
% Compute  min_{x in [0,1]^p} f(x) using projected subgradient descent
%
% if sfm=1, perform submodular function minimization (and adapt gaps and
% function values accordingly)
%
%
% INPUT
% F,param_F: submodular function
% maxiter: maximum number of iterations
%
% OUTPUT
% x: argmin. If sfm=1, then outputs the subset
% values of cost function
% gaps: certified optimaly gaps at each iteration

if nargout>=8
    tic
end

p = param_F.p;

% compute Lipschitz constant
FV = F(1:p,param_F);
Fsingletons = zeros(p,1);
FVsingletons = zeros(p,1);

for i=1:p
    Vmi = 1:p; Vmi(i)=[];
    FVsingletons(i) = FV-F(Vmi,param_F);
    Fsingletons(i) = F(i,param_F);
end
% B = sqrt( sum( max(FVsingletons.^2, Fsingletons.^2) ) );
B = sqrt( sum( (FVsingletons - Fsingletons).^2 ) );
D = sqrt(p);

w = rand(p,1);

% known in advance!
w(find(Fsingletons<=0))=0;
w(find(FVsingletons>=0))=1;

bestvalue = Inf;
s_ave = 0;


for iter =1:maxiter
    if nargout>=8
        added3(iter) = toc;
    end
    [s,Fvalues,order] = greedy_algo_submodular(w,F,param_F);
    s_ave = (s_ave * (iter-1) + s)/(iter);
    
    % compute function values
    [a,b] = min(Fvalues);
    if min(a,0) < bestvalue
        if a < 0
            % allow empty set to be optimal
            Aopt = order(1:b);
            bestvalue = a;
        else
            bestvalue = 0;
            Aopt = [];
        end
    end
    added1(iter)  = s'*w;
    primal_values(iter) = a;
    dual_values(iter) = sum(min(s_ave,0));
    gaps(iter) = primal_values(iter) - dual_values(iter);
    added2(iter) = added1(iter) - dual_values(iter);
    % projected gradient descent
    w = w - sqrt(p) / B / sqrt(iter) * s;
    w = min(max(w,0),1);
    
end
A = Aopt;
x_primal = Aopt;
x_dual = s_ave;


