function y=cummin(x)
% compute cumulative minimum
d=length(x);
y=zeros(size(x));
z=Inf;
for i=1:d,
    z=min(x(i),z);
    y(i)=z;
end