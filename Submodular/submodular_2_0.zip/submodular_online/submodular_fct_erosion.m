function F = submodular_fct_erosion(A,param_F);
% submodular function used for 1D signal processing (to avoid isolated node)
x = sparse(zeros(param_F.p,1)); x(A)=1;
F = sum( max([ x(1:param_F.p-1), x(2:param_F.p) ],[],2) );
 
