function [xs,z0,z] = get_denoising_result(signal,regularizer,p,noise_std,seed,lambdas)% PLOT DENOISING RESULTS
% generate 1D signal and compute proximal operators

% fix random seed for reproducibility
rand('state',seed);
randn('state',seed);




% generate signal
switch signal
    case 1
        % single rectangle
        z0 = zeros(p,1);
        z0(round(3*p/8):round(5*p/8)) = 1;
        z0 = z0 / norm(z0) * sqrt(p);
        z = z0 + noise_std * randn(p,1);
        
    case 2
        % single rectangle - random signs
        z0 = zeros(p,1);
        z0(round(3*p/8):round(5*p/8)) = 1;
        z0 = z0 / norm(z0) * sqrt(p);
        z = z0 + noise_std * randn(p,1);
        s = sign(mod(1:p,2)'-.5);
        z0 = z0 .* s;
        z = z .* s;
        
    case 3
        % single triangle
        z0 = zeros(p,1);
        z0(round(3*p/8):round(4*p/8)) = 1;
        z0(round(4*p/8):round(5*p/8)) = -1;
        z0 = max(cumsum(z0),0);
        z0 = z0 / norm(z0) * sqrt(p);
        z = z0 + noise_std * randn(p,1);
        
    case 4
        % triangle
        z0 = zeros(p,1);
        z0(round(2*p/8):round(3*p/8)) = 1;
        z0(round(5*p/8):round(6*p/8)) = 1;
        z0 = z0 / norm(z0) * sqrt(p);
        z = z0 + noise_std * randn(p,1);
        
        
end




% compute minimizer of .5*||x-z||+lambda * Omega(x)
 

xs = zeros(p,length(lambdas));
switch regularizer
    
    
    case 1
        % range-function + L1 - Linf
        F = @submodular_fct_range;
        param_F.p = p;
        param_F.weight_L1 = 2;
        x=zeros(p,1);
        xs = zeros(p,length(lambdas));
        for ilambda = 1:length(lambdas)
            if  ilambda==1
                [x,bundle] = prox_operator_submodular_absolute_alt(z,lambdas(ilambda),F,param_F,1e-12);
            else
                [x,bundle] = prox_operator_submodular_absolute_alt(z,lambdas(ilambda),F,param_F,1e-12,bundle);
                
            end
            xs(:,ilambda) = x;
        end
        
        
        
    case 2
        % range-function + L2 - Linf
        F = @submodular_fct_range;
        param_F.p = p;
        param_F.weight_L1 = 2;
        
        % solve by eta-trick
        % min_(eta>=0} .5 *lambda * f(eta) + .5*sum( z_i^2 / ( eta_i/lambda + 1)
        eta = zeros(p,1);
        for ilambda=1:length(lambdas)
            lambda = lambdas(ilambda)
            L = max(z.*z / lambda/lambda);
            
            fetas = [];
            eta = eta;
            veta = eta;
            t=1;
            
            % FISTA
            maxiterfista = 200;
            for iterfista=1:maxiterfista
                gradeta = - .5 * z .* z ./ ( 1+ veta/lambda) ./ (1 + veta/lambda) / lambda;
                etaold = eta;
                
                if iterfista==1;
                    [eta,bundle] = prox_operator_submodular_positive(veta - 1/L*gradeta,lambda/2/L,F,param_F,1e-12);
                else
                    [eta,bundle] = prox_operator_submodular_positive(veta - 1/L*gradeta,lambda/2/L,F,param_F,1e-12,bundle);
                end
                s = L*(veta - 1/L*gradeta - eta)/lambda*2;
                told = t;
                t = (1 + sqrt( 1+ 4*t*t ) )/2;
                vetaold = veta;
                veta = eta + ( told - 1 ) / t * ( eta - etaold);
                primal = .5 * sum( z.*z ./ ( 1 + eta/lambda)) + lambda/2 * lovasz_extension(eta,F,param_F);
                dual = .5*sum(z.*z) - .5*sum( max(abs(z)-lambda*sqrt(s),0).^2);
                
                if (primal-dual)<1e-8, break; end
            end
            iterfista
            primal-dual
            xs(:,ilambda) = z ./ ( 1+lambda./eta );
        end
        
        
        
        
    case 3
        % range-function + L2 - overlapping group Lasso L2
        
        % solve by block coordinate descent
        groups = sparse(p,3*p-2);
        weights = ones(3*p-2,1);
        for i=1:p,
            groups(i,i) = 1;
            weights(i) = 2;
        end
        for i=1:p-1
            groups(1:i,i+p) = 1;
        end
        for i=2:p
            groups(i:p,2*p-2+i) = 1;
        end
        
        
        xis = zeros(p,3*p-2);
        y = zeros(p,1);
        
        for ilambda=1:length(lambdas)
            lambda = lambdas(ilambda)
            y = xis * weights * lambda;
            for iterbcd=1:100
                
                for i=1:size(groups,2)
                    candidate = (z-y)/lambda/weights(i) + xis(:,i);
                    candidate = candidate .* groups(:,i);
                    if norm(candidate)>1,
                        candidate = candidate / norm(candidate);
                    end
                    y = y - lambda*weights(i)*(xis(:,i)-candidate);
                    xis(:,i) = candidate;
                    
                end
                x = z - y;
                primal = .5*(x-z)'*(x-z)+lambda* weights'* sqrt(sum(repmat(x.^2,1,length(weights)).*groups))';
                dual = .5*z'*z -.5*(z-y)'*(z-y);
                gap = primal - dual;
                if gap<1e-12, break; end
            end
            xs(:,ilambda) = x;
            
            
            
        end
        
        
        
        
        
        
        
    case 4
        % erosion -function + L1 - Linf
        F = @submodular_fct_erosion;
        param_F.p = p;
        x=zeros(p,1);
        xs = zeros(p,length(lambdas));
        for ilambda = 1:length(lambdas)
            if  ilambda==1
                [x,bundle] = prox_operator_submodular_absolute_alt(z,lambdas(ilambda),F,param_F,1e-12);
            else
                [x,bundle] = prox_operator_submodular_absolute_alt(z,lambdas(ilambda),F,param_F,1e-12,bundle);
                
            end
            xs(:,ilambda) = x;
        end
        
        
        
    case 5
        % erosion-function + L2 - Linf
        F = @submodular_fct_erosion;
        param_F.p = p;
        
        % solve by eta-trick
        % min_(eta>=0} .5 *lambda * f(eta) + .5*sum( z_i^2 / ( eta_i/lambda + 1)
        eta = zeros(p,1);
        for ilambda=1:length(lambdas)
            lambda = lambdas(ilambda)
            L = max(z.*z / lambda/lambda);
            
            fetas = [];
            eta = eta;
            veta = eta;
            t=1;
            
            % FISTA
            maxiterfista = 200;
            for iterfista=1:maxiterfista
                gradeta = - .5 * z .* z ./ ( 1+ veta/lambda) ./ (1 + veta/lambda) / lambda;
                etaold = eta;
                
                if iterfista==1;
                    [eta,bundle] = prox_operator_submodular_positive(veta - 1/L*gradeta,lambda/2/L,F,param_F,1e-12);
                else
                    [eta,bundle] = prox_operator_submodular_positive(veta - 1/L*gradeta,lambda/2/L,F,param_F,1e-12,bundle);
                end
                s = L*(veta - 1/L*gradeta - eta)/lambda*2;
                told = t;
                t = (1 + sqrt( 1+ 4*t*t ) )/2;
                vetaold = veta;
                veta = eta + ( told - 1 ) / t * ( eta - etaold);
                primal = .5 * sum( z.*z ./ ( 1 + eta/lambda)) + lambda/2 * lovasz_extension(eta,F,param_F);
                dual = .5*sum(z.*z) - .5*sum( max(abs(z)-lambda*sqrt(s),0).^2);
                
                if (primal-dual)<1e-8, break; end
            end
            iterfista
            primal-dual
            xs(:,ilambda) = z ./ ( 1+lambda./eta );
        end
        
        
        
        
    case 6
        % erosion-function + L2 - overlapping group Lasso L2
        
        % solve by block coordinate descent
        groups = sparse(p,p-1);
        weights = ones(p-1,1);
        for i=1:p-1,
            groups([i i+1],i) = 1;
            weights(i) = 1;
        end
        
        
        xis = zeros(p,p-1);
        y = zeros(p,1);
        
        for ilambda=1:length(lambdas)
            lambda = lambdas(ilambda)
            y = xis * weights * lambda;
            for iterbcd=1:100
                
                for i=1:size(groups,2)
                    candidate = (z-y)/lambda/weights(i) + xis(:,i);
                    candidate = candidate .* groups(:,i);
                    if norm(candidate)>1,
                        candidate = candidate / norm(candidate);
                    end
                    y = y - lambda*weights(i)*(xis(:,i)-candidate);
                    xis(:,i) = candidate;
                    
                end
                x = z - y;
                primal = .5*(x-z)'*(x-z)+lambda* weights'* sqrt(sum(repmat(x.^2,1,length(weights)).*groups))';
                dual = .5*z'*z -.5*(z-y)'*(z-y);
                gap = primal - dual;
                if gap<1e-12, break; end
            end
            xs(:,ilambda) = x;
            
            
            
        end
        
        
    case 7,
        % L1
        
        xs = zeros(p,length(lambdas));
        for ilambda = 1:length(lambdas)
            
            xs(:,ilambda) = sign(z).*max( abs(z)-lambdas(ilambda),0);
        end
        
        
    case 8,
        % L2
        xs = zeros(p,length(lambdas));
        for ilambda = 1:length(lambdas)
            
            xs(:,ilambda) = z./norm(z)*max(norm(z)-lambdas(ilambda),0);
        end
        
        
    case 9,
        % Linf
        % L2
        xs = zeros(p,length(lambdas));
        for ilambda = 1:length(lambdas)
            xs(:,ilambda) =   prox_operator_Linf(z,lambdas(ilambda));
        end
        
    case 10,
        % TV
        F = @submodular_fct_tv;
        param_F.p = p;
        xs = zeros(p,length(lambdas));
        for ilambda = 1:length(lambdas)
            if  ilambda==1
                [x,bundle] = prox_operator_submodular(z,lambdas(ilambda),F,param_F,1e-12);
            else
                [x,bundle] = prox_operator_submodular(z,lambdas(ilambda),F,param_F,1e-12,bundle);
                
            end
            xs(:,ilambda) = x;
        end
        
        
    case 11,
        % TV + L1
        F = @submodular_fct_tv;
        param_L1 = 1/2;
        param_F.p = p;
        xs = zeros(p,length(lambdas));
        for ilambda = 1:length(lambdas)
            if  ilambda==1
                [x,bundle] = prox_operator_submodular(z,lambdas(ilambda),F,param_F,1e-12);
            else
                [x,bundle] = prox_operator_submodular(z,lambdas(ilambda),F,param_F,1e-12,bundle);
                
            end
            x = sign(x) .* max( abs(x) - param_L1*lambdas(ilambda),0 );
            xs(:,ilambda) = x;
        end
        
    case 12,
        % Laplacian
        L = zeros(p,p);
        for i=1:p-1, L(i,i+1) = 1; L(i+1,i)=1; end
        L = diag(sum(L)) - L;
        
        for ilambda = 1:length(lambdas)
            x = ( eye(p) + lambdas(ilambda) * L ) \ z;
            xs(:,ilambda) = x;
        end
        
        
        
    case 13,
        % Laplacian + L1
        param_L1 = 1/2;
        
        Laplacian = zeros(p,p);
        for i=1:p-1, Laplacian(i,i+1) = 1; Laplacian(i+1,i)=1; end
        Laplacian = diag(sum(Laplacian)) - Laplacian;
        w = zeros(p,1);
        
        
        for ilambda = 1:length(lambdas)
            lambda = lambdas(ilambda);
            
            v = w;
            t = 1;
            L = max(eig(Laplacian))*lambda + 1;
            maxiter_fista = 500;
            for iter=1:maxiter_fista
                gradient = w - z + lambda * Laplacian * w;
                wold = w;
                w = sign(v-1/L * gradient) .* max( abs(v-1/L * gradient) - param_L1 * lambda/L,0);
                told = t;
                t = (1 + sqrt( 1+ 4*t*t ) )/2;
                vold = v;
                v = w + ( told - 1 ) / t * ( w - wold);
            end
            xs(:,ilambda) = w;
        end
        
        
        
        
end
xs = single(xs);

