function f = submodular_fct_cut(A,param);
% submodular cut function
x = sparse(zeros(param.p,1)); x(A)=1;
f =  -.5 * x' * ( param.W * x ) + .5* sum(param.d(A));
f = f - sum( param.s(A) );
