function [primal,dual,solution,certificate] = launch_sfm(dataset,method,maxiter,seed,gap);

% launch sfm for some dataset and some method
if nargin<5, gap = 1e-8; end
% load data
[F,param_F] = load_data_submodular(dataset,seed);

switch method
    
    case 1, % MIN NORM POINT
        [solution,certificate,dual,primal] = minimize_submodular_FW_minnormpoint(F,param_F,maxiter,1,gap);
        
    case 2, % conditional gradient - line search
        [solution,certificate,dual,primal] = minimize_submodular_FW_condgradient(F,param_F,maxiter,1);
        
    case 3, % conditional gradient - no line search (fixed schedule)
        [solution,certificate,dual,primal] = minimize_submodular_FW_condgradient_nolinesearch(F,param_F,maxiter,1);
        
    case 4, % Subgradient descent - no line search (fixed schedule)
        [solution,certificate,dual,primal] = minimize_submodular_projected_subgradient_descent_lovasz(F,param_F,maxiter);
        
    case 5, % Subgradient descent - Polyak's rule
        [solution,certificate,dual,primal] = minimize_submodular_projected_subgradient_descent_lovasz_polyak(F,param_F,maxiter);
        
    case 6, % Ellipsoid
        [solution,certificate,dual,primal]= minimize_submodular_ellipsoid(F,param_F,maxiter);
        
    case 7, % Simplex
        [solution,certificate,dual,primal]= minimize_submodular_simplex(F,param_F,maxiter);
        
     case 8, % ACCPM
        [solution,certificate,dual,primal]= minimize_submodular_accpm(F,param_F,maxiter,gap);

    case 9, % ACCPM - weighted
        [solution,certificate,dual,primal]= minimize_submodular_accpm_weighted(F,param_F,maxiter,gap);

    case 10, % Simplicial CVX
        [solution,certificate,dual,primal]= minimize_submodular_simplex_cvx(F,param_F,maxiter,gap);
        
        
end


