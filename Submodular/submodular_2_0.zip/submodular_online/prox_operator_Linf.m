function w = prox_operator_Linf(z,lambda);
% compute proximal operator for Linf norm
signs = sign(z);
zabs = abs(z);

if length(z)==1
    w = max( zabs - lambda, 0 ) .* signs;
else
    s = simplex_projection(zabs/lambda);
    w = zabs - lambda * s;
    w = max(w,0) .* signs;

end
 