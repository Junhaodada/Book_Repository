function w = prox_operator_submodular_tree(z,lambda,tree,weights,order,children);
% minimize lambda * f(w) + .5 * || w - z ||^2
% for tree functions, using a divide-and-conquer strategy

[ng,p] = size(tree);
if ng==0
    w = z;
    return;
else


    if p==1
        w = z - lambda * weights;

    else
        t = z/lambda - mean(z/lambda) + 1/p * ( weights'*max(tree,[],2) ) ;
        A = minimize_submod_tree(tree,weights,order,children,t);

        if isempty(A)
            A=1:p;
        end
        if length(A)==p
            w = z - lambda * t;

        else

            Ac = 1:p; Ac(A) = [];




            % create new tree-structured groups with appropriate weights
            tree0 = tree(:,A);
            [B,I,J ] = unique(tree0,'rows');

            weights0 = sparse(J,1:ng,ones(ng,1),max(J),ng) * weights;
            % remove empty groups
            ind = find(~any(B,2));
            weights0(ind) = [];
            tree0 = B;
            tree0(ind,:) = [];

            % isolate non-penalized note
            ind = find(any(tree0,1));
            indc = 1:length(A);
            indc(ind) = [];

            [order0,children0 ] = get_children_order(tree0(:,ind));


            w0 = prox_operator_submodular_tree(z(A(ind)),lambda,tree0(:,ind),weights0,order0,children0);

            w0new = zeros(length(A),1);
            w0new(ind) = w0;
            w0new(indc) = z(A(indc));
            w0 = w0new;

            %
            tree1 = tree(:,Ac);
            weights1 = weights;
            weights1( any(tree(:,A),2) ) = 0;
            ind = find(weights1<1e-12);
            weights1(ind) = [];
            tree1(ind,:) = [];


            % isolate non-penalized note
            ind = find(sum(tree1,1));
            indc = 1:length(Ac);
            indc(ind) = [];


            [order1,children1 ] = get_children_order(tree1(:,ind));



            %

            w1 = prox_operator_submodular_tree(z(Ac(ind)),lambda,tree1(:,ind),weights1,order1,children1);

            w1new = zeros(length(Ac),1);
            w1new(ind) = w1;
            w1new(indc) = z(Ac(indc));
            w1 = w1new;



            w = t;
            w(A) = w0;
            w(Ac) = w1;
        end

    end


end


%%%%%%%%%%%%%%%%%%%%%%%%%
function          [order,children ] = get_children_order(tree);
[ng,p] = size(tree);
% build dag
dag = sparse(logical(zeros(ng)));
stree = sum( tree,2 );
for i=1:ng
    dag(i,   sum( tree(:,tree(i,:)),2 ) == stree ) = 1;
end
dag = dag - diag(diag(dag));
% build order
dag_loc = dag;
order = [];
lefttoorder = 1:ng;
while ~isempty(lefttoorder)
    roots = ~any(dag_loc,1);
    order = [ lefttoorder(roots), order ];
    lefttoorder( roots) = [];
    dag_loc(roots,:) = [];
    dag_loc(:,roots) = [];
end

% build children
children = sparse(logical(zeros(ng)));
for i=1:ng
    anc = order(i+min(find(dag(order(i+1:end),order(i)))));
    children(anc,order(i))=1;
end

