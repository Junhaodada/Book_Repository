Documentation of Submodular Package, v2.0, October 2013
Francis Bach, francis.bach@inria.fr

DESCRIPTION

The submodular package is a Matlab program that implements submodular optimization problems to reproduce the figures of the following submission to "Foundations and Trends in Machine Learning".

F. Bach,  Learning with Submodular Functions: A Convex Optimization Perspective, 2013.

INSTALLATION

The scripts to reproduce figures are the following:

online_plot_1D_denoising_results.m
online_plot_figure_wavelet_tree_predictions.m
online_plot_figure_wavelet_tree_speeds_large.m
online_plot_figure_wavelet_tree_speeds_small.m
online_plot_proximal_speed_results.m
online_plot_sfm_speed_results.m

