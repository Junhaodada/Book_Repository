function [primal_variable,dual_variable, dual_values,best_primal_values,gaps,times] = minimize_submodular_simplex_cvx(F,param_F,maxiter,gap)
% Implements the simplex method for submodular function minimization

if nargout>=6
    tic;
end

n = param_F.p;




% use random initialization of permutation
x = greedy_algo_submodular(randn(n,1),F,param_F);

X = x;
eta = 1;
s = x;
w = x*0;
w(find(s<0))=1;


iter = 0;
while iter < maxiter
    iter = iter + 1;
    
    if nargout>=6
        times(iter) = toc;
    end
    
    [new_s,Fvalues,order] = greedy_algo_submodular(w,F,param_F);
    
    primal_values(iter) =  new_s'*w;
    best_primal_values(iter) = min(Fvalues);
    dual_values(iter) = sum(min(s,0));
    gaps(iter) = best_primal_values(iter) - dual_values(iter);
    
    if  gaps(iter) < + gap
        primal_variable = w;
        dual_variable = s;
        
        return;
        
    else
        X = [ X, new_s ];
        
        switch 1
            case 1
                % CVX
                cvx_quiet(true);
                cvx_solver sdpt3;
                cvx_precision default;
                
                cvx_begin
                variable new_eta(size(X,2));
                variable alphas(n);
                variable betas(n);
                dual variable new_w;
                minimize( sum(betas) );
                subject to
                new_w : X * new_eta - alphas + betas == 0;
                sum(new_eta)==1;
                new_eta >= 0;
                alphas >= 0;
                betas >= 0;
                cvx_end
                
            case 2
                % SIMPLEX
                [new_w,new_eta,primalsimplex,dualsimplex] = minimize_submodular_simplex_generic(X,200);
                
        end
        w = new_w;
        eta = new_eta;
        s = X * eta;
        
        w = new_w;
        
    end
end

primal_variable = w;
dual_variable = s;

